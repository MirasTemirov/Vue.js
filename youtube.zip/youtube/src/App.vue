<template>
  <div id="app">
    <h1>Список задач</h1>
    <TaskKey />
  </div>
</template>


<script>
import TaskKey from './components/TaskKey.vue';

export default {
  components: {
    TaskKey,
  },
};
</script>
<style>
body {
  font-family: Arial, sans-serif;
  background-color: #f9f9f9;
  margin: 0;
  padding: 0;
}

#app {
  max-width: 600px;
  margin: 20px auto;
  padding: 20px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

button {
  margin-left: 10px;
  padding: 5px 10px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}

.completed {
  text-decoration: line-through;
}
</style>
