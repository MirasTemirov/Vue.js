<template>
  <div>
    <form @submit.prevent="addTask">
      <input v-model="newTaskTitle" placeholder="Введите задачу" />
      <select v-model="newTaskPriority">
        <option value="low">Низкий</option>
        <option value="medium">Средний</option>
        <option value="high">Высокий</option>
      </select>
      <button type="submit">Добавить</button>
    </form>
    <ul>
      <TaskC
          v-for="task in tasks"
          :key="task.id"
          :task="task"
          @update-task="updateTask"
          @delete-task="deleteTask"
      />
    </ul>
  </div>
</template>

<script>
import TaskC from './TaskC.vue';
import { ref } from 'vue';

export default {
  components: { TaskC },
  setup() {
    const tasks = ref([]);
    const newTaskTitle = ref('');
    const newTaskPriority = ref('low');

    const addTask = () => {
      tasks.value.push({
        id: Date.now(),
        title: newTaskTitle.value,
        priority: newTaskPriority.value,
        completed: false,
      });
      newTaskTitle.value = '';
      newTaskPriority.value = 'low';
    };

    const updateTask = (updatedTask) => {
      const index = tasks.value.findIndex((task) => task.id === updatedTask.id);
      if (index !== -1) tasks.value[index] = updatedTask;
    };

    const deleteTask = (id) => {
      tasks.value = tasks.value.filter((task) => task.id !== id);
    };

    return {
      tasks,
      newTaskTitle,
      newTaskPriority,
      addTask,
      updateTask,
      deleteTask,
    };
  },
};
</script>
