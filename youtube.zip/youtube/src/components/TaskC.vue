<template>
  <li :class="['task-item', { highPriority: task.priority === 'high', completed: task.completed }]">
    <span>{{ task.title }} ({{ task.priority }})</span>
    <button @click="toggleComplete">Завершить</button>
    <button @click="$emit('delete-task', task.id)">Удалить</button>
  </li>
</template>

<script>
export default {
  props: {
    task: {
      type: Object,
      required: true,
    },
  },
  methods: {
    toggleComplete() {
      this.$emit('update-task', { ...this.task, completed: !this.task.completed });
    },
  },
};
</script>
